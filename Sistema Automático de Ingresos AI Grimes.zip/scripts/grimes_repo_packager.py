"""
Script to generate a preconfigured 'grimes-system' GitHub-ready repo
and bundle it into a single ZIP file for easy deployment.
"""

import os
import zipfile

# Base repo configuration
REPO_NAME = "grimes-system"

# Folder structure inside the repo
FOLDERS = [
    "backend",
    "frontend",
    "frontend/assets",
    "ai-engine",
    "ai-engine/templates",
    "automation",
    "config",
]

# File contents for the repo
FILES_CONTENT = {
    # -----------------------
    # Backend
    # -----------------------
    "backend/package.json": '''
{
  "name": "grimes-system",
  "version": "1.0.0",
  "main": "server.js",
  "scripts": {
    "start": "node server.js"
  },
  "dependencies": {
    "express": "^4.18.2",
    "stripe": "^12.14.0",
    "firebase-admin": "^12.0.0",
    "aws-sdk": "^2.1570.0",
    "nodemailer": "^6.9.1",
    "cors": "^2.8.5"
  }
}
''',
    "backend/server.js": '''
import express from 'express';
import cors from 'cors';
import stripeWebhook from './stripe-webhook.js';
import { serveContent } from './content.js';

const app = express();
app.use(cors());
app.use(express.json());

app.post('/stripe-webhook', stripeWebhook);
app.get('/content/:user_id', serveContent);

app.listen(3000, () => console.log("Grimes backend live on port 3000"));
''',
    "backend/stripe-webhook.js": '''
import Stripe from 'stripe';
import { grantAccess, sendLoginEmail } from './grimes.js';

const stripe = new Stripe(process.env.STRIPE_KEY);

export default async function (req, res) {
  const sig = req.headers['stripe-signature'];
  let event;

  try {
    event = stripe.webhooks.constructEvent(
      req.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch (err) {
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const email = session.customer_email;
    await grantAccess(email, session.metadata.product_id);
    await sendLoginEmail(email);
  }
  res.json({ received: true });
}
''',
    "backend/grimes.js": '''
import admin from 'firebase-admin';
import nodemailer from 'nodemailer';
import { db } from './analytics.js';

admin.initializeApp({ credential: admin.credential.applicationDefault() });

export async function grantAccess(email, product_id) {
  const userRef = db.collection('users').doc(email);
  await userRef.set(
    {
      email,
      products: admin.firestore.FieldValue.arrayUnion(product_id),
    },
    { merge: true }
  );
}

export async function sendLoginEmail(email) {
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: { user: process.env.EMAIL_USER, pass: process.env.EMAIL_PASS },
  });

  await transporter.sendMail({
    from: process.env.EMAIL_USER,
    to: email,
    subject: 'Your Grimes Access',
    html: `<p>Login: <a href="https://grimes.com/login">Click Here</a></p>`,
  });
}
''',
    "backend/content.js": '''
import AWS from 'aws-sdk';

const s3 = new AWS.S3({ region: process.env.AWS_REGION });

export async function serveContent(req, res) {
  const { user_id } = req.params;
  const key = `products/${user_id}/main.zip`;

  try {
    const url = await s3.getSignedUrlPromise('getObject', {
      Bucket: process.env.S3_BUCKET,
      Key: key,
      Expires: 3600,
    });
    res.json({ download_url: url });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
''',
    "backend/analytics.js": '''
import admin from 'firebase-admin';

admin.initializeApp();
export const db = admin.firestore();

export async function logEvent(user_id, event, value) {
  await db.collection('events').add({
    user_id,
    event,
    value,
    timestamp: new Date(),
  });
}
''',

    # -----------------------
    # Frontend
    # -----------------------
    "frontend/index.html": '''
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Grimes AI System</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  <section class="hero">
    <h1>Automated AI Income System</h1>
    <p>Get instant access to your automated revenue path.</p>
    <a id="cta" href="#" class="cta-button">Get Access Now</a>
  </section>
  <script src="scripts.js"></script>
</body>
</html>
''',
    "frontend/style.css": '''
body {
  margin: 0;
  font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  background: #050816;
  color: #f9fafb;
}

.hero {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  padding: 2rem;
}

.hero h1 {
  font-size: 2.75rem;
  margin-bottom: 1rem;
}

.hero p {
  font-size: 1.1rem;
  max-width: 28rem;
  margin-bottom: 2rem;
  color: #d1d5db;
}

.cta-button {
  display: inline-block;
  padding: 0.9rem 2.4rem;
  border-radius: 999px;
  background: #22c55e;
  color: #030712;
  font-weight: 600;
  text-decoration: none;
  transition: transform 0.15s ease-out, box-shadow 0.15s ease-out,
    background 0.15s ease-out;
  box-shadow: 0 18px 45px rgba(34, 197, 94, 0.4);
}

.cta-button:hover {
  background: #16a34a;
  transform: translateY(-1px);
  box-shadow: 0 24px 60px rgba(34, 197, 94, 0.55);
}
''',
    "frontend/scripts.js": '''
document.addEventListener('DOMContentLoaded', () => {
  const cta = document.getElementById('cta');
  if (!cta) return;

  cta.addEventListener('click', (event) => {
    event.preventDefault();
    window.location.href = 'https://buy.stripe.com/test_xyz';
  });
});
''',

    # -----------------------
    # AI Engine
    # -----------------------
    "ai-engine/content-generator.py": '''
import os
import json
import boto3
import openai

openai.api_key = os.getenv("OPENAI_KEY")
s3 = boto3.client("s3")


def generate_content(prompt: str) -> str:
  """
  Generate marketing / funnel content using OpenAI ChatCompletion.
  """
  res = openai.ChatCompletion.create(
      model="gpt-4",
      messages=[{"role": "user", "content": prompt}],
  )
  return res.choices[0].message.content


def upload_content(product_id: str, content: str) -> None:
  """
  Upload generated content to S3 for the given product.
  """
  bucket = os.getenv("S3_BUCKET")
  key = f"products/{product_id}/content.txt"
  s3.put_object(Bucket=bucket, Key=key, Body=content.encode("utf-8"))


if __name__ == "__main__":
  prompt = "Create viral AI revenue funnel post content"
  content = generate_content(prompt)
  upload_content("product_001", content)
''',
    "ai-engine/scheduler.py": '''
import time
import schedule
import subprocess


def run_daily() -> None:
  """
  Run the content generator script once per day.
  """
  subprocess.run(["python", "content-generator.py"], check=True)


schedule.every().day.at("09:00").do(run_daily)

if __name__ == "__main__":
  while True:
    schedule.run_pending()
    time.sleep(60)
''',

    # -----------------------
    # Automation
    # -----------------------
    "automation/upsell-sequence.js": '''
import fetch from 'node-fetch';
import { logEvent } from '../backend/analytics.js';

export async function triggerUpsell(user_email) {
  await fetch(`https://grimes.com/api/send-upsell?email=${encodeURIComponent(user_email)}`);
  await logEvent(user_email, 'upsell_sent', 1);
}
''',
    "automation/zapier.json": '''
{
  "trigger": "stripe.checkout.session.completed",
  "actions": [
    { "action": "POST", "url": "https://grimes.com/api/create-user" },
    { "action": "POST", "url": "https://grimes.com/api/grant-access" },
    { "action": "POST", "url": "https://grimes.com/api/send-login-email" }
  ]
}
''',

    # -----------------------
    # Config
    # -----------------------
    "config/env.example": '''
STRIPE_KEY=sk_test_xyz
STRIPE_WEBHOOK_SECRET=whsec_xyz
AWS_REGION=us-east-1
S3_BUCKET=grimes-content
OPENAI_KEY=sk-xyz
EMAIL_USER=youremail@gmail.com
EMAIL_PASS=emailpassword
FIREBASE_PROJECT_ID=grimes-project
''',
    "config/firebase.json": '''
{
  "projectId": "grimes-project",
  "databaseURL": "https://grimes-project.firebaseio.com"
}
''',
    "config/aws.json": '''
{
  "region": "us-east-1",
  "bucket": "grimes-content"
}
''',

    # -----------------------
    # Root helper files
    # -----------------------
    "README.md": '''
# Grimes System

Fully automated AI gangster-path revenue system.

## Structure

- \`backend/\` – Node.js + Express API (Stripe webhook, content delivery, analytics)
- \`frontend/\` – Static funnel page wired to Stripe checkout
- \`ai-engine/\` – OpenAI + S3 content generation + daily scheduler
- \`automation/\` – Upsell sequence + Zapier workflow JSON
- \`config/\` – Example environment + cloud configs

## Quickstart

1. \`cd backend && npm install && npm start\`
2. Copy \`config/env.example\` to \`.env\` and fill in real values.
3. Deploy backend (Node server / Heroku / Vercel).
4. Upload products to S3 bucket defined in \`config/aws.json\`.
5. Serve \`frontend/\` as a static site (e.g. on Vercel / Netlify / Shopify theme).
6. Configure Stripe checkout + webhook to hit \`/stripe-webhook\`.
7. Import \`automation/zapier.json\` into Zapier/Make.
8. Run \`ai-engine/scheduler.py\` on a cron-capable host.

Use at your own risk. Check and harden security, auth, and rate limits before production.
'''
}


def create_repo_structure(base_dir: str) -> None:
    """
    Create the folder structure and write all files for the repo.
    """
    os.makedirs(base_dir, exist_ok=True)

    # Ensure folders exist
    for folder in FOLDERS:
        folder_path = os.path.join(base_dir, folder)
        os.makedirs(folder_path, exist_ok=True)

    # Write all declared files
    for rel_path, content in FILES_CONTENT.items():
        full_path = os.path.join(base_dir, rel_path)
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        with open(full_path, "w", encoding="utf-8") as f:
            f.write(content.strip() + "\n")


def create_zip(base_dir: str, zip_name: str) -> None:
    """
    Zip the entire repo directory into a single archive.
    """
    with zipfile.ZipFile(zip_name, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, _, files in os.walk(base_dir):
            for file in files:
                abs_path = os.path.join(root, file)
                rel_path = os.path.relpath(abs_path, os.path.dirname(base_dir))
                zf.write(abs_path, rel_path)


if __name__ == "__main__":
    root_dir = os.getcwd()
    repo_dir = os.path.join(root_dir, REPO_NAME)
    zip_path = os.path.join(root_dir, f"{REPO_NAME}.zip")

    create_repo_structure(repo_dir)
    create_zip(repo_dir, zip_path)

    print(f"Repo created at: {repo_dir}")
    print(f"Zip archive created: {zip_path}")